package com.blockshorts.app

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings

/**
 * Tile long-press par khulti hai. Koi UI nahi: seedha accessibility permission screen khol kar band ho jaati hai.
 * Launcher me icon nahi.
 */
class SetupActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        openAccessibility()
        finish()
    }

    private fun openAccessibility() {
        val component = ComponentName(this, BlockAccessibilityService::class.java).flattenToString()
        try {
            // Naye Android par seedha BlockShorts ke page par le jaata hai
            startActivity(
                Intent("android.settings.ACCESSIBILITY_DETAILS_SETTINGS")
                    .putExtra(Intent.EXTRA_COMPONENT_NAME, component)
            )
        } catch (_: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } catch (_: Exception) { }
        }
    }
}
