package com.blockshorts.app

import android.app.PendingIntent
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class BlockTileService : TileService() {

    override fun onStartListening() = refresh()

    override fun onClick() {
        // Accessibility band hai to pehle use ON karwao; ON hone ke baad tile sirf ON/OFF toggle karti hai
        if (!BlockAccessibilityService.running) {
            openAccessibilitySettings()
            return
        }
        Prefs.setEnabled(this, !Prefs.isEnabled(this))
        refresh()
    }

    private fun refresh() {
        val tile = qsTile ?: return
        val on = BlockAccessibilityService.running && Prefs.isEnabled(this)
        tile.state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = getString(R.string.tile_label)
        tile.icon = Icon.createWithResource(this, R.drawable.ic_tile)
        tile.updateTile()
    }

    @Suppress("DEPRECATION")
    private fun openAccessibilitySettings() {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(
                PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)
            )
        } else {
            startActivityAndCollapse(intent)
        }
    }
}
