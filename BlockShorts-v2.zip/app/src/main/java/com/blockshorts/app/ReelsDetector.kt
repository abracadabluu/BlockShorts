package com.blockshorts.app

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Reels/Shorts detection. Ye code background thread (Dispatchers.Default) par chalta hai.
 *
 * Overlay SIRF TARGET_APPS me aur SIRF tab dikhta hai jab full-screen vertical video feed dikhe.
 * Naya app block karna ho to uska package name TARGET_APPS me daalo.
 *
 * NOTE: Resource-ids app update ke saath badal sakte hain. Naye ids Layout Inspector /
 * uiautomatorviewer se nikaal kar KNOWN_IDS me daal dena.
 */
object ReelsDetector {

    val TARGET_APPS: Set<String> = setOf(
        "com.google.android.youtube",
        "com.instagram.android",
        "com.instagram.lite",
        "com.facebook.katana",
        "com.facebook.lite",
        "com.snapchat.android",
        "in.mohalla.video",
        "in.mohalla.sharechat",
        "com.zhiliaoapp.musically"
    )

    fun isTargetApp(pkg: String) = pkg in TARGET_APPS

    /** Fast path: exact resource-id lookup. */
    private val KNOWN_IDS: Map<String, List<String>> = mapOf(
        "com.google.android.youtube" to listOf(
            "reel_recycler", "reel_player_page_container", "reel_watch_fragment_root"
        ),
        "com.instagram.android" to listOf(
            "clips_viewer_view_pager", "clips_viewer_container", "clips_swipe_refresh_container"
        )
    )

    /** Fallback: id me ye words ho (aur node lamba/full-screen ho). */
    private val KEYWORDS = listOf(
        "reel", "shorts", "short_video", "spotlight", "clips_viewer", "vertical_video", "video_feed"
    )
    /** Stories / tabs / buttons ko reels na samajh le. */
    private val EXCLUDE = listOf("tray", "story", "stories", "shelf", "tab", "button", "icon", "pivot", "nav", "ring")

    private const val MAX_NODES = 600
    private const val MAX_DEPTH = 30

    private fun tallEnough(node: AccessibilityNodeInfo, screenH: Int, ratio: Float, rect: Rect): Boolean {
        node.getBoundsInScreen(rect)
        return rect.height() >= screenH * ratio
    }

    fun isReels(root: AccessibilityNodeInfo, pkg: String, screenH: Int): Boolean {
        val rect = Rect()
        val ids = KNOWN_IDS[pkg]
        if (ids != null) {
            for (id in ids) {
                val list = root.findAccessibilityNodeInfosByViewId("$pkg:id/$id") ?: continue
                val hit = list.any { it.isVisibleToUser && tallEnough(it, screenH, 0.5f, rect) }
                @Suppress("DEPRECATION") list.forEach { it.recycle() }
                if (hit) return true
            }
        }
        return keywordScan(root, screenH, rect)
    }

    private fun keywordScan(root: AccessibilityNodeInfo, screenH: Int, rect: Rect): Boolean {
        val stack = ArrayDeque<Pair<AccessibilityNodeInfo, Int>>()
        stack.addLast(root to 0)
        var visited = 0
        while (stack.isNotEmpty() && visited < MAX_NODES) {
            val (node, depth) = stack.removeLast()
            visited++
            val name = node.viewIdResourceName?.substringAfter(":id/")?.lowercase()
            if (name != null &&
                KEYWORDS.any { name.contains(it) } &&
                EXCLUDE.none { name.contains(it) } &&
                node.isVisibleToUser &&
                tallEnough(node, screenH, 0.6f, rect)
            ) return true
            if (depth < MAX_DEPTH) {
                for (i in 0 until node.childCount) {
                    node.getChild(i)?.let { stack.addLast(it to depth + 1) }
                }
            }
        }
        return false
    }
}
