package com.blockshorts.app

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val FILE = "blockshorts_prefs"
    const val KEY_ENABLED = "enabled"

    fun sp(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun isEnabled(ctx: Context): Boolean = sp(ctx).getBoolean(KEY_ENABLED, true)

    fun setEnabled(ctx: Context, value: Boolean) {
        sp(ctx).edit().putBoolean(KEY_ENABLED, value).apply()
    }
}
