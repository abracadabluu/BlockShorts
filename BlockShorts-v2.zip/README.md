# BlockShorts
Parental-control tool: bachche ke phone par sirf Reels/Shorts jaisi full-screen vertical-video tab par fake "buffering" overlay dikhata hai.

- Overlay status bar aur navigation bar ko nahi dhakta: Back/Home chalte hain, status bar swipe-down se Quick Settings khulti hai.
- Neeche app ka tab bar khula rehta hai (`OverlayController.BOTTOM_APP_BAR_DP`).
- Reels se bahar nikalte hi (back / tab change / koi aur app) overlay hat jaata hai.
- Sirf `ReelsDetector.TARGET_APPS` ki apps me kaam karta hai.
- App drawer me icon nahi.

## Setup
1. APK install karo.
2. Android 13+: Settings > Apps > BlockShorts > ⋮ > "Allow restricted settings".
3. Quick Settings > Edit > "BlockShorts" tile add karo.
4. Tile long-press (ya tile tap, jab tak service band ho) => Accessibility settings => BlockShorts ON.
5. Uske baad tile tap = ON/OFF.
