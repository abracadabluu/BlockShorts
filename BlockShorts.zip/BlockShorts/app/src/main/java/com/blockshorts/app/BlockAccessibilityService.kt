package com.blockshorts.app

import android.accessibilityservice.AccessibilityService
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class BlockAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var running = false
        private const val SYSTEM_UI = "com.android.systemui"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val main = Handler(Looper.getMainLooper())
    private var job: Job? = null
    private lateinit var overlay: OverlayController
    @Volatile private var enabled = true

    // Strong reference zaroori hai warna listener GC ho jaata hai
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { sp, key ->
        if (key == Prefs.KEY_ENABLED) {
            enabled = sp.getBoolean(Prefs.KEY_ENABLED, true)
            if (!enabled) main.post { overlay.hide() }
        }
    }

    override fun onServiceConnected() {
        overlay = OverlayController(this)
        enabled = Prefs.isEnabled(this)
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(prefListener)
        running = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (!enabled) return
        val pkg = event.packageName?.toString() ?: return
        val isState = event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED

        if (pkg == packageName || pkg == SYSTEM_UI) return

        if (pkg.contains("launcher") || pkg == "com.android.settings") {
            if (isState) main.post { overlay.hide() }
            return
        }

        // Throttle: evaluate chal rahi ho to content-change events skip
        if (!isState && job?.isActive == true) return
        job?.cancel()
        job = scope.launch { evaluate(pkg) }
    }

    private suspend fun evaluate(pkg: String) {
        val screenH = resources.displayMetrics.heightPixels
        var misses = 0
        while (true) {
            val root = rootInActiveWindow
            val rootPkg = root?.packageName?.toString() ?: pkg
            val hit = root != null && ReelsDetector.isReels(root, rootPkg, screenH)
            if (hit) {
                withContext(Dispatchers.Main) { overlay.show() }
                break
            }
            if (!overlay.isShowing) break
            // Flicker se bachne ke liye overlay hatane se pehle ek baar re-check
            if (++misses >= 2) {
                withContext(Dispatchers.Main) { overlay.hide() }
                break
            }
            delay(300)
        }
        delay(150)
    }

    override fun onInterrupt() {
        main.post { overlay.hide() }
    }

    override fun onDestroy() {
        running = false
        Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(prefListener)
        scope.cancel()
        if (::overlay.isInitialized) overlay.hide()
        super.onDestroy()
    }
}
