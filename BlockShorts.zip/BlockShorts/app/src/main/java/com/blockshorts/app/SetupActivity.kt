package com.blockshorts.app

import android.app.Activity
import android.app.StatusBarManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Launcher me nahi dikhti. Tile long-press (ya Settings > Apps) se khulti hai. */
class SetupActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        root.addView(TextView(this).apply { text = "BlockShorts"; textSize = 26f })
        status = TextView(this).apply { textSize = 16f; setPadding(0, pad / 2, 0, pad / 2) }
        root.addView(status)

        root.addView(Button(this).apply {
            text = "1. Accessibility service ON karo"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        if (Build.VERSION.SDK_INT >= 33) {
            root.addView(Button(this).apply {
                text = "2. Quick Settings tile add karo"
                setOnClickListener { addTile() }
            })
        } else {
            root.addView(TextView(this).apply {
                text = "2. Quick Settings panel > Edit (pencil) > BlockShorts tile ko upar kheencho."
            })
        }
        root.addView(TextView(this).apply {
            text = "\nAndroid 13+ par sideload ke baad: Settings > Apps > BlockShorts > ⋮ > " +
                "'Allow restricted settings', phir accessibility ON karo."
            textSize = 13f
        })
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        status.text = if (BlockAccessibilityService.running)
            "Status: Accessibility service chal rahi hai ✅ (tile se ON/OFF karo)"
        else "Status: Accessibility service band hai ❌"
    }

    private fun addTile() {
        if (Build.VERSION.SDK_INT >= 33) {
            val sbm = getSystemService(StatusBarManager::class.java)
            sbm.requestAddTileService(
                ComponentName(this, BlockTileService::class.java),
                getString(R.string.tile_label),
                Icon.createWithResource(this, R.drawable.ic_block),
                mainExecutor
            ) { }
        }
    }
}
