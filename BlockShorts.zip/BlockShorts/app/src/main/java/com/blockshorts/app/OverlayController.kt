package com.blockshorts.app

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.view.Gravity
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ProgressBar

/** Fake "buffering" full-screen overlay. show()/hide() sirf main thread se call karo. */
class OverlayController(private val service: AccessibilityService) {

    private val wm = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val audio = service.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    @Volatile var isShowing = false
        private set

    private val focusRequest: AudioFocusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                .build()
        )
        .setOnAudioFocusChangeListener { }
        .build()

    private val view: FrameLayout by lazy {
        val dp = service.resources.displayMetrics.density
        FrameLayout(service).apply {
            setBackgroundColor(Color.BLACK)
            val spinner = ProgressBar(service).apply {
                isIndeterminate = true
                indeterminateTintList = ColorStateList.valueOf(Color.parseColor("#E0E0E0"))
            }
            addView(
                spinner,
                FrameLayout.LayoutParams((48 * dp).toInt(), (48 * dp).toInt(), Gravity.CENTER)
            )
        }
    }

    private fun params() = WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
        PixelFormat.OPAQUE
    ).apply { gravity = Gravity.TOP or Gravity.START }

    fun show() {
        if (isShowing) return
        try {
            wm.addView(view, params())
            isShowing = true
            // Best-effort: peeche chal rahi reel ki awaaz/playback rokne ke liye
            audio.requestAudioFocus(focusRequest)
        } catch (_: Exception) { }
    }

    fun hide() {
        if (!isShowing) return
        try { wm.removeView(view) } catch (_: Exception) { }
        isShowing = false
        audio.abandonAudioFocusRequest(focusRequest)
    }
}
