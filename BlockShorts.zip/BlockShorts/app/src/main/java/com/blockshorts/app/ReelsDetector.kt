package com.blockshorts.app

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Reels/Shorts detection. Ye code background thread (Dispatchers.Default) par chalta hai.
 *
 * NOTE: Resource-ids app update ke saath badal sakte hain. Naye ids uiautomatorviewer /
 * Android Studio Layout Inspector se nikaal kar KNOWN_IDS me daal dena.
 */
object ReelsDetector {

    /** Fast path: exact resource-id lookup (findAccessibilityNodeInfosByViewId). */
    private val KNOWN_IDS: Map<String, List<String>> = mapOf(
        "com.google.android.youtube" to listOf(
            "reel_recycler", "reel_player_page_container", "reel_watch_fragment_root"
        ),
        "com.instagram.android" to listOf(
            "clips_viewer_view_pager", "clips_viewer_container", "clips_swipe_refresh_container"
        )
    )

    /** Baaki saari apps (Moj, Snapchat, TikTok clones, Facebook...) ke liye keyword scan. */
    private val KEYWORDS = listOf(
        "reel", "shorts", "short_video", "spotlight", "clips_viewer", "vertical_video", "video_feed"
    )
    /** Instagram me stories ko bhi "reels_tray" bolte hain, isliye ye words exclude. */
    private val EXCLUDE = listOf("tray", "story", "stories", "shelf", "tab", "button", "icon", "pivot", "nav")

    private const val MAX_NODES = 600
    private const val MAX_DEPTH = 30

    fun isReels(root: AccessibilityNodeInfo, pkg: String, screenH: Int): Boolean {
        val ids = KNOWN_IDS[pkg]
        if (ids != null) {
            for (id in ids) {
                val list = root.findAccessibilityNodeInfosByViewId("$pkg:id/$id") ?: continue
                val hit = list.any { it.isVisibleToUser }
                @Suppress("DEPRECATION") list.forEach { it.recycle() }
                if (hit) return true
            }
            return false
        }
        return keywordScan(root, screenH)
    }

    private fun keywordScan(root: AccessibilityNodeInfo, screenH: Int): Boolean {
        val stack = ArrayDeque<Pair<AccessibilityNodeInfo, Int>>()
        stack.addLast(root to 0)
        var visited = 0
        val rect = Rect()
        while (stack.isNotEmpty() && visited < MAX_NODES) {
            val (node, depth) = stack.removeLast()
            visited++
            val name = node.viewIdResourceName?.substringAfter(":id/")?.lowercase()
            if (name != null &&
                KEYWORDS.any { name.contains(it) } &&
                EXCLUDE.none { name.contains(it) } &&
                node.isVisibleToUser
            ) {
                node.getBoundsInScreen(rect)
                if (rect.height() >= screenH * 0.6f) return true
            }
            if (depth < MAX_DEPTH) {
                for (i in 0 until node.childCount) {
                    node.getChild(i)?.let { stack.addLast(it to depth + 1) }
                }
            }
        }
        return false
    }
}
