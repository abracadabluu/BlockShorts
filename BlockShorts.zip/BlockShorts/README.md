# BlockShorts
Parental-control tool: bachche ke device par Reels/Shorts screen detect hote hi fake "buffering" overlay dikhata hai.
Quick Settings tile se ON/OFF. App drawer me icon nahi.

## Setup
1. APK install karo.
2. Settings > Accessibility > Installed apps > BlockShorts > ON (Android 13+: pehle App info > "Allow restricted settings").
3. Quick Settings > Edit > "BlockShorts" tile add karo (tile long-press = setup screen).
4. Tile tap = ON/OFF.

## Customize
`ReelsDetector.kt` me `KNOWN_IDS` me naye app ke resource-ids add karo.
