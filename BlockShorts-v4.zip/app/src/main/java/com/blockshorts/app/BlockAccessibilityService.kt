package com.blockshorts.app

import android.accessibilityservice.AccessibilityService
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class BlockAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var running = false
        private const val SYSTEM_UI = "com.android.systemui"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val main = Handler(Looper.getMainLooper())

    // CONFLATED: sirf sabse naya event bachta hai => purane/bekaar evaluations nahi jama hote
    private val trigger = Channel<String>(Channel.CONFLATED)
    private var worker: Job? = null
    @Volatile private var latestPkg = ""

    private lateinit var overlay: OverlayController
    @Volatile private var enabled = true

    // Strong reference zaroori hai warna listener GC ho jaata hai
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { sp, key ->
        if (key == Prefs.KEY_ENABLED) {
            enabled = sp.getBoolean(Prefs.KEY_ENABLED, true)
            if (!enabled) main.post { overlay.hide() }
        }
    }

    override fun onServiceConnected() {
        overlay = OverlayController(this)
        overlay.prepare()   // view pehle se bana kar rakho => show() turant
        enabled = Prefs.isEnabled(this)
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(prefListener)
        running = true
        worker?.cancel()
        worker = scope.launch { for (pkg in trigger) evaluate(pkg) }
    }

    private fun isIgnorable(pkg: String): Boolean =
        pkg == packageName || pkg == SYSTEM_UI ||
            pkg.contains("inputmethod") || pkg.contains("keyboard") || pkg.contains("honeyboard")

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (!enabled) return
        val pkg = event.packageName?.toString() ?: return
        if (isIgnorable(pkg)) return
        latestPkg = pkg

        if (!ReelsDetector.isTargetApp(pkg)) {
            // Koi bhi non-target app / launcher / settings => overlay turant hata do
            if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                main.postAtFrontOfQueue { if (latestPkg == pkg) overlay.hide() }
            }
            return
        }
        trigger.trySend(pkg)
    }

    private suspend fun evaluate(pkg: String) {
        val screenW = resources.displayMetrics.widthPixels
        val screenH = resources.displayMetrics.heightPixels
        var misses = 0
        while (latestPkg == pkg) {
            // Active window is app ki nahi (jaise notification shade khuli hai) => kuchh mat badlo
            val root = rootInActiveWindow ?: return
            if (root.packageName?.toString() != pkg) return

            // Overlay dikha hua ho to hide-check cheap rakho (sirf tab-scan se dikha ho to scan bhi)
            val allowSlow = !overlay.isShowing || ReelsDetector.lastWasSlow
            if (ReelsDetector.isReels(root, pkg, screenW, screenH, allowSlow)) {
                withContext(Dispatchers.Main.immediate) {
                    if (latestPkg == pkg) {
                        val was = overlay.isShowing
                        overlay.show()
                        if (ReelsDetector.DEBUG && !was) {
                            Toast.makeText(this@BlockAccessibilityService, ReelsDetector.lastReason, Toast.LENGTH_SHORT).show()
                        }
                    }
                }
                break
            }
            if (!overlay.isShowing) break
            // Ek chhota re-check (40ms) taaki transition ke beech ka flicker na ho
            if (++misses >= 2) {
                withContext(Dispatchers.Main.immediate) { if (latestPkg == pkg) overlay.hide() }
                break
            }
            delay(40)
        }
        delay(if (overlay.isShowing) 80 else 40)
    }

    override fun onInterrupt() {
        main.post { overlay.hide() }
    }

    override fun onDestroy() {
        running = false
        worker?.cancel()
        trigger.close()
        Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(prefListener)
        scope.cancel()
        if (::overlay.isInitialized) overlay.hide()
        super.onDestroy()
    }
}
