package com.blockshorts.app

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.KeyEvent
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ProgressBar

/**
 * Fake "buffering" overlay. show()/hide() sirf main thread se call karo.
 *
 * Overlay POORI screen nahi dhakta:
 *  - upar status bar ka area khula rehta hai  => notification/quick settings swipe-down chalta hai
 *  - neeche navigation bar ka area khula rehta hai => back / home / recents chalte hain
 *  - neeche app ka apna tab bar (BOTTOM_APP_BAR_DP) khula rehta hai => bachcha Home tab par ja sakta hai
 */
class OverlayController(private val service: AccessibilityService) {

    companion object {
        /** App ke bottom tab bar ke liye chhodi gayi jagah. Agar tab bar dab raha ho to badhao. */
        const val BOTTOM_APP_BAR_DP = 64
    }

    private val wm = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val audio = service.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    @Volatile var isShowing = false
        private set

    private val focusRequest: AudioFocusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                .build()
        )
        .setOnAudioFocusChangeListener { }
        .build()

    private val handler = Handler(Looper.getMainLooper())
    private var mutedByUs = false

    /** Jab tak overlay hai, har ~700ms par background audio rokte raho (autoplay/next short ke liye bhi). */
    private val silencer = object : Runnable {
        override fun run() {
            if (!isShowing) return
            silence()
            handler.postDelayed(this, 700)
        }
    }

    private fun silence() {
        try {
            // 1) Chal rahi media ko pause karo (YouTube audio focus ignore kar deta hai)
            if (audio.isMusicActive) {
                audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PAUSE))
                audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PAUSE))
            }
            // 2) Pakka silence: music stream mute (overlay hatne par wapas unmute)
            if (!mutedByUs && !audio.isStreamMute(AudioManager.STREAM_MUSIC)) {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
                mutedByUs = true
            }
        } catch (_: Exception) { }
    }

    private fun restoreAudio() {
        try {
            if (mutedByUs) {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
            }
        } catch (_: Exception) { }
        mutedByUs = false
    }

    private val view: FrameLayout by lazy {
        val dp = service.resources.displayMetrics.density
        FrameLayout(service).apply {
            setBackgroundColor(Color.BLACK)
            val spinner = ProgressBar(service).apply {
                isIndeterminate = true
                indeterminateTintList = ColorStateList.valueOf(Color.parseColor("#E0E0E0"))
            }
            addView(
                spinner,
                FrameLayout.LayoutParams((48 * dp).toInt(), (48 * dp).toInt(), Gravity.CENTER)
            )
        }
    }

    private fun screenHeight(): Int {
        if (Build.VERSION.SDK_INT >= 30) {
            try { return wm.maximumWindowMetrics.bounds.height() } catch (_: Exception) { }
        }
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
        return dm.heightPixels
    }

    /** (status bar height, navigation bar height) in pixels */
    private fun systemBars(): Pair<Int, Int> {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val i = wm.currentWindowMetrics.windowInsets.getInsetsIgnoringVisibility(
                    WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout()
                )
                if (i.top > 0 || i.bottom > 0) return i.top to i.bottom
            } catch (_: Exception) { }
        }
        fun dimen(name: String): Int {
            val id = service.resources.getIdentifier(name, "dimen", "android")
            return if (id > 0) service.resources.getDimensionPixelSize(id) else 0
        }
        return dimen("status_bar_height") to dimen("navigation_bar_height")
    }

    private fun params(): WindowManager.LayoutParams {
        val (top, bottom) = systemBars()
        val gap = (BOTTOM_APP_BAR_DP * service.resources.displayMetrics.density).toInt()
        val height = (screenHeight() - top - bottom - gap).coerceAtLeast(1)
        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            height,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.OPAQUE
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = top
        }
    }

    /** Service connect par ek baar bulao: view pehle se ban jaaye, show() me deri na ho. */
    fun prepare() { view }

    fun show() {
        if (isShowing) return
        try {
            wm.addView(view, params())
            isShowing = true
            audio.requestAudioFocus(focusRequest)
            silence()
            handler.postDelayed(silencer, 700)
        } catch (_: Exception) { }
    }

    fun hide() {
        if (!isShowing) return
        try { wm.removeView(view) } catch (_: Exception) { }
        isShowing = false
        handler.removeCallbacks(silencer)
        restoreAudio()
        audio.abandonAudioFocusRequest(focusRequest)
    }
}
