package com.blockshorts.app

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Reels/Shorts detection. Background thread par chalta hai. Tez rakhne ke liye pehle sirf
 * "cheap" checks (kuch hi IPC calls) chalte hain; poora tree-scan tabhi jab cheap checks kuchh na dein.
 *
 * Faisla:
 *  1. Neeche ke bar me SELECTED tab "Shorts"/"Reels" hai            => block
 *  2. Full-screen vertical video player visible hai (known id / keyword)
 *       - agar koi AUR tab (Home, Subscriptions...) selected hai, to player tabhi maana jaata hai
 *         jab wo lagbhag poori screen ghere (Home se khola gaya short). Chhupa/purana node ignore.
 *       - warna                                                       => block
 *  3. Baaki sab                                                       => block nahi
 *
 * Tab-labels English UI maan kar hain (Home/Subscriptions...). Hindi UI me tab-signal nahi milega,
 * tab player-detection hi kaam karegi.
 */
object ReelsDetector {

    /** true karke build karo: overlay aate hi toast me wajah dikhegi (debugging ke liye). */
    const val DEBUG = false
    @Volatile var lastReason: String = ""
    /** Pichla "block" faisla slow tree-scan se aaya tha? Tab hide-check bhi scan se hona chahiye. */
    @Volatile var lastWasSlow: Boolean = false

    val TARGET_APPS: Set<String> = setOf(
        "com.google.android.youtube",
        "com.instagram.android",
        "com.instagram.lite",
        "com.facebook.katana",
        "com.facebook.lite",
        "com.snapchat.android",
        "in.mohalla.video",
        "in.mohalla.sharechat",
        "com.zhiliaoapp.musically"
    )

    fun isTargetApp(pkg: String) = pkg in TARGET_APPS

    private val KNOWN_IDS: Map<String, List<String>> = mapOf(
        "com.google.android.youtube" to listOf(
            "reel_recycler", "reel_player_page_container", "reel_watch_fragment_root"
        ),
        "com.instagram.android" to listOf(
            "clips_viewer_view_pager", "clips_viewer_container", "clips_swipe_refresh_container"
        )
    )

    private val KEYWORDS = listOf(
        "reel", "shorts", "short_video", "spotlight", "clips_viewer", "vertical_video", "video_feed"
    )
    private val EXCLUDE = listOf("tray", "story", "stories", "shelf", "tab", "button", "icon", "pivot", "nav", "ring")

    private val SHORTS_TAB_WORDS = listOf("Shorts", "Reels", "शॉर्ट", "रील")
    private val OTHER_TAB_WORDS = listOf(
        "Home", "Subscriptions", "You", "Library", "Search", "Explore", "Profile", "Messages"
    )

    private const val MAX_NODES = 400
    private const val MAX_DEPTH = 30

    private class Hit(val h: Float, val w: Float)

    /** allowSlow=false => sirf cheap checks (hide-check ke liye, taaki jaldi ho). */
    fun isReels(
        root: AccessibilityNodeInfo, pkg: String, screenW: Int, screenH: Int, allowSlow: Boolean
    ): Boolean {
        val rect = Rect()
        lastWasSlow = false

        if (selectedTab(root, SHORTS_TAB_WORDS, screenW, screenH, rect)) {
            lastReason = "shorts-tab"; return true
        }

        var hit = knownIdHit(root, pkg, screenW, screenH, rect)
        var slow = false
        if (hit == null && allowSlow) {
            hit = keywordScan(root, screenW, screenH, rect)
            slow = hit != null
        }
        if (hit == null) { lastReason = "none"; return false }

        if (selectedTab(root, OTHER_TAB_WORDS, screenW, screenH, rect)) {
            val fullscreen = hit.h >= 0.8f && hit.w >= 0.9f
            lastReason = if (fullscreen) "fullscreen-player (other tab)" else "other-tab"
            lastWasSlow = fullscreen && slow
            return fullscreen
        }
        lastReason = if (slow) "keyword-player" else "known-player"
        lastWasSlow = slow
        return true
    }

    /** Neeche ke bar me koi visible + SELECTED item jiska label words me se ek ho. (findByText = 1 IPC) */
    private fun selectedTab(
        root: AccessibilityNodeInfo, words: List<String>, screenW: Int, screenH: Int, rect: Rect
    ): Boolean {
        for (w in words) {
            val list = root.findAccessibilityNodeInfosByText(w) ?: continue
            var found = false
            for (n in list) {
                if (!n.isVisibleToUser) continue
                n.getBoundsInScreen(rect)
                if (rect.top < screenH * 0.75f || rect.width() > screenW * 0.5f || rect.height() > screenH * 0.2f) continue
                var cur: AccessibilityNodeInfo? = n
                var depth = 0
                while (cur != null && depth < 3) {
                    if (cur.isSelected) { found = true; break }
                    cur = cur.parent
                    depth++
                }
                if (found) break
            }
            @Suppress("DEPRECATION") list.forEach { it.recycle() }
            if (found) return true
        }
        return false
    }

    private fun knownIdHit(
        root: AccessibilityNodeInfo, pkg: String, screenW: Int, screenH: Int, rect: Rect
    ): Hit? {
        val ids = KNOWN_IDS[pkg] ?: return null
        var best: Hit? = null
        for (id in ids) {
            val list = root.findAccessibilityNodeInfosByViewId("$pkg:id/$id") ?: continue
            for (n in list) {
                if (!n.isVisibleToUser) continue
                n.getBoundsInScreen(rect)
                val h = rect.height().toFloat() / screenH
                if (h >= 0.5f && (best == null || h > best.h)) best = Hit(h, rect.width().toFloat() / screenW)
            }
            @Suppress("DEPRECATION") list.forEach { it.recycle() }
            if (best != null) return best
        }
        return best
    }

    private fun keywordScan(root: AccessibilityNodeInfo, screenW: Int, screenH: Int, rect: Rect): Hit? {
        val stack = ArrayDeque<Pair<AccessibilityNodeInfo, Int>>()
        stack.addLast(root to 0)
        var visited = 0
        while (stack.isNotEmpty() && visited < MAX_NODES) {
            val (node, depth) = stack.removeLast()
            visited++
            if (!node.isVisibleToUser) continue   // chhupe fragments/tabs skip
            node.getBoundsInScreen(rect)
            val name = node.viewIdResourceName?.substringAfter(":id/")?.lowercase()
            if (name != null &&
                KEYWORDS.any { name.contains(it) } &&
                EXCLUDE.none { name.contains(it) } &&
                rect.height() >= screenH * 0.6f
            ) return Hit(rect.height().toFloat() / screenH, rect.width().toFloat() / screenW)
            if (depth < MAX_DEPTH) {
                for (i in 0 until node.childCount) {
                    node.getChild(i)?.let { stack.addLast(it to depth + 1) }
                }
            }
        }
        return null
    }
}
