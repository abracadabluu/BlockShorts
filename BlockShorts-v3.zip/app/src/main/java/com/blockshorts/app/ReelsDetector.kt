package com.blockshorts.app

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Reels/Shorts detection. Background thread (Dispatchers.Default) par chalta hai.
 *
 * Faisla 3 signals se hota hai (is order me):
 *  1. Neeche ke tab bar me jo tab SELECTED hai uska naam: "Shorts"/"Reels" => block,
 *     "Home"/"Subscriptions"/"You"... => block NAHI (purane/chhupe reel nodes ignore).
 *  2. KNOWN_IDS: app ke known reels resource-ids (visible + lamba).
 *  3. KEYWORDS: id me reel/shorts jaise words (visible + lamba).
 *
 * Naya app block karna ho to package name TARGET_APPS me daalo.
 */
object ReelsDetector {

    /** true karke build karo: overlay aate hi toast me wajah dikhegi (debugging ke liye). */
    const val DEBUG = false
    @Volatile var lastReason: String = ""

    val TARGET_APPS: Set<String> = setOf(
        "com.google.android.youtube",
        "com.instagram.android",
        "com.instagram.lite",
        "com.facebook.katana",
        "com.facebook.lite",
        "com.snapchat.android",
        "in.mohalla.video",
        "in.mohalla.sharechat",
        "com.zhiliaoapp.musically"
    )

    fun isTargetApp(pkg: String) = pkg in TARGET_APPS

    private val KNOWN_IDS: Map<String, List<String>> = mapOf(
        "com.google.android.youtube" to listOf(
            "reel_recycler", "reel_player_page_container", "reel_watch_fragment_root"
        ),
        "com.instagram.android" to listOf(
            "clips_viewer_view_pager", "clips_viewer_container", "clips_swipe_refresh_container"
        )
    )

    private val KEYWORDS = listOf(
        "reel", "shorts", "short_video", "spotlight", "clips_viewer", "vertical_video", "video_feed"
    )
    private val EXCLUDE = listOf("tray", "story", "stories", "shelf", "tab", "button", "icon", "pivot", "nav", "ring")

    /** Selected bottom-tab ke label me ye ho to wo reels/shorts tab hai. */
    private val SHORTS_TAB_WORDS = listOf("shorts", "reels", "reel", "clips", "शॉर्ट", "रील")

    private const val MAX_NODES = 900
    private const val MAX_DEPTH = 30

    private class Scan {
        var shortsTab = false
        var otherTab = false
        var tabLabel = ""
        var keyword: String? = null
    }

    fun isReels(root: AccessibilityNodeInfo, pkg: String, screenW: Int, screenH: Int): Boolean {
        val rect = Rect()
        val sc = scan(root, screenW, screenH, rect)
        val result: Boolean
        when {
            sc.shortsTab -> { lastReason = "tab:" + sc.tabLabel.trim(); result = true }
            sc.otherTab -> { lastReason = "other-tab:" + sc.tabLabel.trim(); result = false }
            knownIdHit(root, pkg, screenH, rect) -> { lastReason = "known-id"; result = true }
            sc.keyword != null -> { lastReason = "keyword:" + sc.keyword; result = true }
            else -> { lastReason = "none"; result = false }
        }
        return result
    }

    private fun knownIdHit(root: AccessibilityNodeInfo, pkg: String, screenH: Int, rect: Rect): Boolean {
        val ids = KNOWN_IDS[pkg] ?: return false
        for (id in ids) {
            val list = root.findAccessibilityNodeInfosByViewId("$pkg:id/$id") ?: continue
            val hit = list.any {
                it.isVisibleToUser && run { it.getBoundsInScreen(rect); rect.height() >= screenH * 0.5f }
            }
            @Suppress("DEPRECATION") list.forEach { it.recycle() }
            if (hit) return true
        }
        return false
    }

    private fun scan(root: AccessibilityNodeInfo, screenW: Int, screenH: Int, rect: Rect): Scan {
        val out = Scan()
        val stack = ArrayDeque<Pair<AccessibilityNodeInfo, Int>>()
        stack.addLast(root to 0)
        var visited = 0
        val bottomTop = screenH * 0.8f
        while (stack.isNotEmpty() && visited < MAX_NODES) {
            val (node, depth) = stack.removeLast()
            visited++
            // Chhupe hue (hidden fragment/tab) nodes aur unke bachche ignore
            if (!node.isVisibleToUser) continue
            node.getBoundsInScreen(rect)
            val name = node.viewIdResourceName?.substringAfter(":id/")?.lowercase()

            if (out.keyword == null && name != null &&
                KEYWORDS.any { name.contains(it) } &&
                EXCLUDE.none { name.contains(it) } &&
                rect.height() >= screenH * 0.6f
            ) out.keyword = name

            if (node.isSelected && rect.top >= bottomTop &&
                rect.width() < screenW * 0.5f && rect.height() < screenH * 0.2f
            ) {
                val label = ((node.contentDescription?.toString() ?: "") + " " +
                    (node.text?.toString() ?: "") + " " + (name ?: "")).lowercase()
                if (label.isNotBlank()) {
                    if (SHORTS_TAB_WORDS.any { label.contains(it) }) out.shortsTab = true else out.otherTab = true
                    out.tabLabel = label
                }
            }

            if (depth < MAX_DEPTH) {
                for (i in 0 until node.childCount) {
                    node.getChild(i)?.let { stack.addLast(it to depth + 1) }
                }
            }
        }
        return out
    }
}
